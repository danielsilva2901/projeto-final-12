use dbinfop;
describe tbusers;
select * from tbservice_order;
-- adiciona uma coluna na tabela
alter table tbusers add column perfil varchar(20) not null;
describe tbusers;
-- remove um campo na tabela
alter table tbusers drop column perfil;
update tbusers set perfil='admin' where iduser=1;
update tbusers set perfil='admin' where iduser=2;
insert into tbusers(iduser,utilizador,fone,login,pass_word,perfil)
values(3,'José Ramos','984512447','joseramos','joseramos123','user');
describe tbclients;
select idclient as ID_Cliente, name_client as Nome, endclient as Morada, foneclient as Telefone, email_client as Email, client_postalcode as Código_Postal from tbclients; 
describe tbservice_order;
select idclient, name_client, foneclient from tbclients where name_client like 'jo%';
select idclient as ID_Cliente, name_client as Nome, endclient as Morada, foneclient as Telefone from tbclients where name_client like 'jo%'; 
describe tbservice_order;
alter table tbservice_order add tipo varchar(15) not null after data_serviceorder;
alter table tbservice_order add situacao varchar(20) not null after tipo;
alter table tbservice_order modify tipo varchar(20) not null;
alter table tbservice_order modify situacao varchar(30) not null;
select service_order, date_format(data_serviceorder,'%d/%m/%Y - %H:%i'),tipo,situacao,equipament,fault,type_service,tecnico,valor,idclient from tbservice_order;
select * from tbclients;
select * from tbclients order by idclient;
select * from tbusers;
Select utilizador from tbusers where iduser=1;
select name_client from tbclients where idclient=1;
select service_order as numos, date_format(data_serviceorder,'%d/%m/%Y - %H:%i') as data,tipo as tipoos,situacao,equipament,fault,type_service as tiposerv,tecnico,valor,idclient from tbservice_order;
-- uniao de duas tabelas
select OSER.service_order,date_format(data_serviceorder,'%d/%m/%Y - %H:%i') as data,tipo,situacao,equipament,valor, CLI.name_client,foneclient,email_client from tbservice_order as OSER inner join tbclients as CLI on (CLI.idclient = OSER.idclient);
select * from tbservice_order where service_order=14;