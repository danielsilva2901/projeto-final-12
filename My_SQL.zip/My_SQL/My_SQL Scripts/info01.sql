
-- a linha abaixo cria um banco de dados
create database dbinfop;
-- a linha abaixo escolhe o banco de dados
use dbinfop;
--  bloco de instrucoes abaixo cria uma tabela
create table tbusers(
	iduser int primary key,
    utilizador varchar(50) not null,
    fone varchar(15),
    login varchar(15) not null unique,
    pass_word varchar(15) not null
);
-- descrever a tabela
describe tbusers;
-- inserir dados na tabela
-- criar
insert into tbusers(iduser,utilizador,fone,login,pass_word)
values(1,'Daniel Silva','9999-9999','danielsilva','123456');
-- exibir os dados
-- ler
select * from tbusers;

insert into tbusers(iduser,utilizador,fone,login,pass_word)
values(2,'Administrador','9999-9999','admin','admin');
insert into tbusers(iduser,utilizador,fone,login,pass_word)
values(3,'Lucas Oliveira','9999-9999','lucasoliveira','lucas123456');
select * from tbusers;

-- modificar dados na tabela
-- update
update tbusers set fone ='8888-8888' where iduser ='2';
select * from tbusers;

-- apagar um user
delete from tbusers where iduser = '3';
select * from tbusers;

CREATE TABLE tbclients (
    idclient INT PRIMARY KEY AUTO_INCREMENT,
    name_client VARCHAR(50) NOT NULL,
    endclient VARCHAR(100),
    foneclient VARCHAR(50) NOT NULL,
    email_client VARCHAR(50)
);

describe tbclients;

insert into tbclients(name_client,endclient,foneclient,email_client)
values('Lucas Oliveira', 'Rua Tux, 2015', '9999-9999', 'lucas.oliveira.fotos@gmail.com');
select * from tbclients;
alter table tbclients
add client_postalcode varchar(15);

describe tbclients;

update tbclients set client_postalcode = '1842-755 'where idclient ='1';
select * from tbclients;

create table tbservice_order(
	service_order int primary key auto_increment,
    -- apresenta automaticamente a data e hora quando uma ordem é criada
    data_serviceorder timestamp default current_timestamp,
    equipament varchar(150) not null,
    fault varchar(150) not null,
    type_service varchar(150),
    tecnico varchar(30),
    -- formatar o resultado pelo mysql
    valor decimal(10,2),
    -- faz a conexao entre a tabela de servico e a tabela de clientes
    idclient int not null,
    foreign key(idclient) references tbclients(idclient)
);

select * from tbservice_order;
describe tbservice_order;

insert into tbservice_order(equipament, fault, type_service, tecnico, valor, idclient)
values ('Portátil','Não Liga', 'Troca da placa-mãe', 'Pedro Silva', 130.50, 1);
select * from tbservice_order;

-- unir informacoes de duas tabelas
select
O.service_order,equipament,fault,type_service,valor,
C.name_client,foneclient,email_client
from tbservice_order as O
inner join tbclients as C
on (O.idclient = C.idclient);
